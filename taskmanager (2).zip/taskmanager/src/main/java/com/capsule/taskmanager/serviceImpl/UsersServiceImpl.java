package com.capsule.taskmanager.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capsule.taskmanager.model.Users;
import com.capsule.taskmanager.repository.ProjectRepo;
import com.capsule.taskmanager.repository.UsersRepo;
import com.capsule.taskmanager.service.UsersService;

@Service("usersService")
public class UsersServiceImpl implements UsersService{
	
	private UsersRepo usersRepo;
	private ProjectRepo projectRepo;
	@Autowired
	public UsersServiceImpl(UsersRepo usersRepo, ProjectRepo projectRepo) {
		this.usersRepo = usersRepo;
		this.projectRepo = projectRepo;
	}

	@Override
	public Users createUsers(Users users) {
		usersRepo.save(users);
	}

	@Override
	public List<Users> getUsers() {
		return usersRepo.findAll();
	}

	@Override
	public Users findUserByFirstName(String firstName) {
		return null;
	}

	@Override
	public Users findUserByLastName(String lastName) {
		return null;
	}

	@Override
	public Users findById(Long userId) {
		return null;
	}

	@Override
	public void editUser(Users users, Long userId) {
		
	}

	@Override
	public void deleteUser(Long userId) {
		
	}

}
