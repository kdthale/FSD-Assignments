package com.capsule.taskmanager.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="project")
public class Project {
	
	@Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Column(name = "projectid")
	private Long projectId;
	
	@Column(name = "projectname")
	private String projectName;
	
	@Column(name = "projectstartdate")
	@JsonFormat(pattern="dd/mm/yyyy") 
	private Date projectStartDate;	

	@Column(name = "enddate")
	@JsonFormat(pattern="dd/mm/yyyy") 
	private Date projectEndDate;
	
	@Column(name= "priority")
	private Integer priority;
	
	@Column(name= "projectstatus")
	private String projectStatus;

	public Project() {
		super();
	}
	
	public Project(Long projectId, String projectName, Date projectStartDate, Date projectEndDate, Integer priority,String projectStatus) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectStartDate = projectStartDate;
		this.projectEndDate = projectEndDate;
		this.priority = priority;
		this.projectStatus = projectStatus;
		
	}

	public Long getProjectId() {
		return projectId;
	}

	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public Date getProjectStartDate() {
		return projectStartDate;
	}

	public void setProjectStartDate(Date projectStartDate) {
		this.projectStartDate = projectStartDate;
	}

	public Date getProjectEndDate() {
		return projectEndDate;
	}

	public void setProjectEndDate(Date projectEndDate) {
		this.projectEndDate = projectEndDate;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getProjectStatus() {
		return projectStatus;
	}

	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName=" + projectName + ", projectStartDate="
				+ projectStartDate + ", projectEndDate=" + projectEndDate + ", priority=" + priority
				+ ", projectStatus=" + projectStatus + "]";
	}
	
	}
