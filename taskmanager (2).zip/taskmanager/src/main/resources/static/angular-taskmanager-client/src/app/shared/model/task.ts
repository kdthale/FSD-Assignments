export class Task {
	taskId:number;
	taskName:string;
	priorityFrom:number;
	priorityTo:number;
	parentTaskName:string;
	startDate:string;
	endDate:string;
	taskStatus:String
}
