export const environment = {
  production: false,
  employeesUrl: 'http://localhost:3000/employees',
  employeeDetailsUrl: 'http://localhost:3000/employee-details',
};
