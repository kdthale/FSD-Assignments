import { HeaderService } from './header.service';

describe('HeaderService', () => {

  let service: HeaderService;

  beforeEach(() => { service = new HeaderService(); });

  it('should return correct header title', () => {
    const title = 'title hero';
    service.setHeader(title);
    expect(service.getHeader()).toBe(title);
  });
});

