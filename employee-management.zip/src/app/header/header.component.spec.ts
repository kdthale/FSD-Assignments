import { TestBed, async, ComponentFixture } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { HeaderService } from './header.service';

describe('HeaderComponent', () => {

  let component: HeaderComponent;
  let headerService: HeaderService;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HeaderComponent],
      providers: [HeaderService]
    });
    TestBed.compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    headerService = fixture.debugElement.injector.get(HeaderService);
  });

  afterEach(() => fixture.destroy());

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show header title', () => {
    const title = 'Hello Title';
    spyOn(headerService, 'getHeader').and.returnValue(title);
    fixture.detectChanges();

    const headerElement = fixture.nativeElement.querySelector('.title-bar__title') as HTMLElement;
    expect(headerElement.textContent).toContain(title);
  });
});
