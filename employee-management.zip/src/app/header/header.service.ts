import { Injectable } from '@angular/core';

@Injectable()
export class HeaderService {
  public header: string;

  public setHeader(header: string): void {
    this.header = header;
  }

  public getHeader(): string {
    return this.header;
  }
}
