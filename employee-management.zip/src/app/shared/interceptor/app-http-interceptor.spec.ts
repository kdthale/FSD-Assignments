import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { EmployeesService } from '../../employees/services/employees.service';
import { AppHttpInterceptor } from './app-http-interceptor';

describe(`AppHttpInterceptor`, () => {

  let employeesService: EmployeesService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [
        EmployeesService,
        { provide: HTTP_INTERCEPTORS, useClass: AppHttpInterceptor, multi: true },
      ]
    });
  });

  beforeEach(() => {
    employeesService = TestBed.get(EmployeesService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should add an content-type header', () => {
    employeesService.getEmployees().subscribe(response => {
      expect(response).toBeTruthy();
    });
    const httpRequest = httpMock.expectOne('http://localhost:3000/employees');
    expect(httpRequest.request.headers.has('Content-Type')).toEqual(true);
  });
});
