import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { StarRatingComponent } from './star-rating.component';
import { By } from '@angular/platform-browser';

describe('StarRatingComponent', () => {
  let component: StarRatingComponent;
  let fixture: ComponentFixture<StarRatingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [StarRatingComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StarRatingComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => fixture.destroy());

  describe('When disable mode is On', () => {
    beforeEach(() => {
      spyOn(component.savedRating, 'emit').and.callThrough();
      component.initialRating = 3;
      fixture.detectChanges();
    });

    it('should show selected star equals to preSelectedRating', () => {
      const selectedRatingElement = fixture.nativeElement.querySelectorAll('.selected-icon');
      expect(selectedRatingElement.length).toEqual(3);
    });

    it('should not emit savedRating', () => {
      const selectedRatingElement = fixture.nativeElement.querySelector('.selected-icon') as HTMLElement;
      selectedRatingElement.click();
      expect(component.savedRating.emit).not.toHaveBeenCalled();
    });
  });

  describe('When disable mode is off', () => {

    beforeEach(() => {
      spyOn(component.savedRating, 'emit').and.callThrough();
      spyOn(component, 'onHovering').and.callThrough();
      spyOn(component, 'onUnovering').and.callThrough();
      component.initialRating = 3;
      component.isDisabled = false;
      fixture.detectChanges();
    });

    it('should show selected star equals to preSelectedRating', () => {
      const selectedRatingElement = fixture.nativeElement.querySelectorAll('.selected-icon');
      expect(selectedRatingElement.length).toEqual(3);
    });

    it('should emit savedRating', () => {
      const selectedRatingElement = fixture.nativeElement.querySelector('.selected-icon') as HTMLElement;
      selectedRatingElement.click();
      expect(component.savedRating.emit).toHaveBeenCalled();
    });

    it('should call onHovering method when mouse entre on star', () => {
      const selectedRatingElement = fixture.debugElement.query(By.css('.selected-icon'));
      selectedRatingElement.triggerEventHandler('mouseenter', null);
      fixture.detectChanges();
      expect(component.onHovering).toHaveBeenCalled();
    });

    it('should call onUnovering method when mouse leave on star', () => {
      const selectedRatingElement = fixture.debugElement.query(By.css('.selected-icon'));
      selectedRatingElement.triggerEventHandler('mouseleave', null);
      fixture.detectChanges();
      expect(component.onUnovering).toHaveBeenCalled();
      expect(component.selectedRating).toBe(3);
    });

    it('should call onUnovering method and set selected rating value', () => {
      const selectedRatingElement = fixture.debugElement.query(By.css('.selected-icon'));
      component.selectedRating = 5;
      component.initialRating = 4;
      component.isRatingSelected = true;
      fixture.detectChanges();
      selectedRatingElement.triggerEventHandler('mouseleave', null);
      expect(component.selectedRating).toBe(5);
    });
  });
});
