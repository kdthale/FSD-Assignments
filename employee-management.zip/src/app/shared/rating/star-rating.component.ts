import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

@Component({
  selector: 'app-star-rating',
  templateUrl: 'star-rating.component.html',
  styleUrls: ['star-rating.component.scss']
})

export class StarRatingComponent implements OnInit {

  @Input() public initialRating = 0;
  @Input() public ratinglist: number[] = [1, 2, 3, 4, 5];
  @Input() public isDisabled = true;

  @Output() public savedRating = new EventEmitter<number>();

  public selectedRating: number;
  public isRatingSelected = false;

  public ngOnInit() {
    this.selectedRating = this.initialRating;
  }

  public editRating(rating: number) {
    if (!this.isDisabled) {
    this.isRatingSelected = true;
    this.initialRating = rating;
    this.selectedRating = this.initialRating;
    this.savedRating.emit(rating);
    }
  }

  public onHovering(e: number) {
    if (!this.isDisabled) {
      this.isRatingSelected = false;
      this.selectedRating = e;
    }
  }

  public onUnovering() {
    if (!this.isDisabled) {
      this.selectedRating = this.isRatingSelected ? this.selectedRating : this.initialRating;
    }
  }
}
