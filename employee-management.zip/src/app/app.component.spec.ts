import { TestBed, async, ComponentFixture } from '@angular/core/testing';

import { AppComponent } from './app.component';
import { AppModule } from './app.module';

describe('AppComponent', () => {

  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [AppModule],
    });
    TestBed.compileComponents();
  });

  beforeEach(() => {
  fixture = TestBed.createComponent(AppComponent);
  component = fixture.componentInstance;
});

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should have app header', () => {
    const HeaderElement = fixture.nativeElement.querySelector('app-header');
    expect(HeaderElement).toBeTruthy();
  });
});

