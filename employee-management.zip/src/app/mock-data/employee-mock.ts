import { Employee, EmployeeDetails } from '../employees/models/employee.model';

export const EmployeeList: Employee[] = [
  {
    id: 1,
    firstName: 'Rolf',
    lastName: 'Dool',
    projectName: 'Technium',
    mobileNumber: 1235987888,
    emailId: 'rolf.dool@kpn.com'
  },
  {
    id: 2,
    firstName: 'Robert',
    lastName: 'Metselaar',
    projectName: 'Technium',
    mobileNumber: 9571356,
    emailId: 'robert.metselaar@kpn.com'
  },
  {
    id: 3,
    firstName: 'Sergiu',
    lastName: 'Tomsa',
    projectName: 'Technium',
    mobileNumber: 515495,
    emailId: 'sergiu.tomsa@kpn.com'
  },
  {
    id: 4,
    firstName: 'Jordy',
    lastName: 'Bulten',
    projectName: 'Technium',
    mobileNumber: 14565454,
    emailId: 'jordy.bulten@kpn.com'
  },
  {
    id: 5,
    firstName: 'Rohit',
    lastName: 'Singh',
    projectName: 'Technium',
    mobileNumber: 86456456,
    emailId: 'rohit.singh@kpn.com'
  },
  {
    id: 6,
    firstName: 'Deepak',
    lastName: 'kedia',
    projectName: 'Technium',
    mobileNumber: 5456456,
    emailId: 'deepak.kedia@kpn.com'
  },
  {
    id: 7,
    firstName: 'Vandana',
    lastName: 'Shrivastava',
    projectName: 'Technium',
    mobileNumber: 12345677,
    emailId: 'vandana.shrivastava@cognizant.com'
  },
  {
    id: 8,
    firstName: 'Remko',
    lastName: 'Bor',
    projectName: 'Technium',
    mobileNumber: 454654,
    emailId: 'remko.bor@kpn.com'
  },
  {
    id: 9,
    firstName: 'Ben',
    lastName: 'Besuijen',
    projectName: 'Technium',
    mobileNumber: 54564564,
    emailId: 'ben.besuijen@kpn.com'
  },
  {
    id: 10,
    firstName: 'Martijn',
    lastName: 'Hoedelmans',
    projectName: 'KPN Operations',
    mobileNumber: 1545454564,
    emailId: 'martijn.hoedelmans@kpn.com'
  }
];

export const EmployeeDetailsData: EmployeeDetails = {
  id: 1,
  firstName: 'Rolf',
  lastName: 'Dool',
  projectName: 'Technium',
  mobileNumber: 1564564156,
  emailId: 'rolf.dool@kpn.com',
  gender: 'male',
  workAddress: {
      AppartmentNumber: '1',
      StreetName: 'Street one',
      city: 'amsterdam',
      zipcode: '1177JT',
      country: 'Netherlands',
  },
  homeAddress: {
      AppartmentNumber: '1',
      StreetName: 'street name',
      city: 'amsterdam',
      zipcode: 'wers 23',
      country: 'Netherlands',
  },
  hobbies: 'chess',
  rating: 4
};
