import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderService } from '../header/header.service';
import { PageNotFoundComponent } from './page-not-found.component';

describe('PageNotFoundComponent', () => {
  let component: PageNotFoundComponent;
  let fixture: ComponentFixture<PageNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PageNotFoundComponent],
      providers: [HeaderService]
    })
    .compileComponents();
  }));

  afterEach(() => fixture.destroy());

  beforeEach(() => {
    fixture = TestBed.createComponent(PageNotFoundComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show Page not found page', () => {
    const text = 'Page Not Found';
    fixture.detectChanges();
    const blockElement = fixture.nativeElement.querySelector('.block__title');
    expect(blockElement.textContent).toContain(text);
  });
});
