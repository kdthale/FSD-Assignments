import { Component, OnInit } from '@angular/core';

import { HeaderService } from '../header/header.service';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html'
})
export class PageNotFoundComponent implements OnInit {

  constructor( public readonly headerService: HeaderService) { }

  ngOnInit() {
    this.headerService.setHeader('Page not found');
  }
}
