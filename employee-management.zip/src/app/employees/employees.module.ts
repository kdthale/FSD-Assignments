import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RatingModule } from '../shared/rating/star-rating.module';
import { EmployeesComponent } from './employees.component';
import { EmployeeDetailsComponent } from './details/employee-details.component';
import { EmployeesRoutingModule } from './employees-routing.module';
import { EmployeesService} from './services/employees.service';

@NgModule({
  declarations: [
    EmployeesComponent,
    EmployeeDetailsComponent,
  ],
  imports: [
    CommonModule,
    RatingModule,
    EmployeesRoutingModule
  ],
  providers: [EmployeesService]
})
export class EmployeesModule { }
