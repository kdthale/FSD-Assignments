export interface Address {
  AppartmentNumber: string;
  StreetName: string;
  city: string;
  zipcode: string;
  country: string;
}

export interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  projectName: string;
  emailId: string;
  mobileNumber: number;
}

export interface EmployeeDetails extends Employee {
  gender: string;
  workAddress: Address;
  homeAddress: Address;
  rating: number;
  hobbies: string;
}
