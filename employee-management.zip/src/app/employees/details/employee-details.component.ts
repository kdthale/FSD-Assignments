import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { publishReplay, refCount } from 'rxjs/operators';

import { Employee, Address } from '../models/employee.model';
import { HeaderService } from '../../header/header.service';
import { EmployeesService } from '../services/employees.service';

@Component({
  selector: 'app-employee-details',
  templateUrl: './employee-details.component.html',
  styleUrls: ['./employee-details.component.scss']
})
export class EmployeeDetailsComponent implements OnInit {

  public employeeDetails$: Observable<Employee>;
  public isRatingDisabled = true;
  public savedRating: number;

  constructor(
    public router: Router,
    public activatedRoute: ActivatedRoute,
    public headerService: HeaderService,
    public employeeService: EmployeesService
    ) { }

  public ngOnInit() {
    this.headerService.setHeader('Employees Details');
    this.employeeDetails$ = this.employeeService.getEmployeeDetails(this.activatedRoute.snapshot.params['id']).pipe(
      publishReplay(1),
      refCount()
    );
  }

  public editRating(rating: number) {
    this.isRatingDisabled = true;
    this.savedRating = rating;
  }

  public formatAddress(attributes: string[]): string {
    return attributes ? attributes.filter((part) => !!part).join(' ') : '';
  }

  public back() {
    this.router.navigate(['employees']);
  }

  public toggleEditMode() {
    this.isRatingDisabled = !this.isRatingDisabled;
    this.savedRating = undefined;
  }
}
