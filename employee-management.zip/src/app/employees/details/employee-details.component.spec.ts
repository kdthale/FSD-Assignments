import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';

import { EmployeesService } from '../services/employees.service';
import { HeaderService } from '../../header/header.service';
import { EmployeeDetailsData } from '../../mock-data/employee-mock';
import { EmployeesModule } from '../employees.module';
import { EmployeeDetailsComponent } from './employee-details.component';

describe('EmployeeDetailsComponent', () => {
  let router: Router;
  let component: EmployeeDetailsComponent;
  let employeesService: EmployeesService;
  let headerService: HeaderService;
  let fixture: ComponentFixture<EmployeeDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
        EmployeesModule
      ],
      providers: [
        HeaderService,
        { provide: ActivatedRoute, useValue: { snapshot: { params: 1 } }}
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeDetailsComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    employeesService = fixture.debugElement.injector.get(EmployeesService);
    headerService = fixture.debugElement.injector.get(HeaderService);
  });

  afterEach(() => fixture.destroy());

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call fetch employee details on initial load', () => {
    spyOn(employeesService, 'getEmployeeDetails').and.returnValue(of(EmployeeDetailsData));
    fixture.detectChanges();

    const labelElement = fixture.nativeElement.querySelector('.content__body') as HTMLElement;
    expect(labelElement.textContent).toContain(EmployeeDetailsData.firstName);
    expect(labelElement.textContent).toContain(EmployeeDetailsData.lastName);
    expect(labelElement.textContent).toContain(EmployeeDetailsData.gender);
    expect(labelElement.textContent).toContain(EmployeeDetailsData.projectName);
  });

  it('should set header title', () => {
    spyOn(headerService, 'setHeader');
    const title = 'Employees Details';
    fixture.detectChanges();
    expect(headerService.setHeader).toHaveBeenCalledWith(title);
  });

  it('should toggle edit mode', () => {
    component.isRatingDisabled = true;
    expect(component.isRatingDisabled).toBe(true);
    component.toggleEditMode();
    expect(component.isRatingDisabled).toBe(false);
    component.toggleEditMode();
    expect(component.isRatingDisabled).toBe(true);
  });

  it('should naviagte to employee overview when back mathod is called', fakeAsync(() => {
    const navigateSpy = spyOn(router, 'navigate');
    component.back();
    expect(navigateSpy).toHaveBeenCalledWith(['employees']);
  }));

  it('should call editRating set rating and disable the rating', () => {
    spyOn(component, 'editRating').and.callThrough();
    spyOn(employeesService, 'getEmployeeDetails').and.returnValue(of(EmployeeDetailsData));
    component.toggleEditMode();
    fixture.detectChanges();
    const starRatingElement = fixture.nativeElement.querySelector('.star-icon') as HTMLElement;
    starRatingElement.click();
    fixture.detectChanges();
    const selectedRatingElement = fixture.nativeElement.querySelectorAll('.selected-icon');
    expect(component.editRating).toHaveBeenCalledWith(5);
    expect(selectedRatingElement.length).toBe(5);
    fixture.detectChanges();
    expect(component.isRatingDisabled).toBe(true);
  });

  it('should format address', () => {
    const result1 = component.formatAddress(['text1', '', 'text']);
    expect(result1).toBe('text1 text');

    const result2 = component.formatAddress([]);
    expect(result2).toBe('');

    const result3 = component.formatAddress(null);
    expect(result3).toBe('');
  });
});
