import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { publishReplay, refCount } from 'rxjs/operators';

import { HeaderService } from '../header/header.service';
import { Employee } from './models/employee.model';
import { EmployeesService } from './services/employees.service';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.scss']
})
export class EmployeesComponent implements OnInit {

  public employees$: Observable<Employee[]>;

  constructor(
    public readonly router: Router,
    public readonly headerService: HeaderService,
    public readonly employeeService: EmployeesService
  ) { }

  public ngOnInit() {
    this.headerService.setHeader('Employees Overview');
    this.employees$ = this.employeeService.getEmployees().pipe(
      publishReplay(1),
      refCount()
    );
  }

  public rowClick(data: Employee) {
    this.router.navigate(['employees/details', data.id]);
  }
}
