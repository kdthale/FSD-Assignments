import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { EmployeesComponent } from './employees.component';
import { EmployeeDetailsComponent } from './details/employee-details.component';

const employeesRoutes: Routes = [
  {
    path: '',
    component: EmployeesComponent
  },
  {
    path: 'details/:id',
    component: EmployeeDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(employeesRoutes)],
  exports: [RouterModule]
})
export class EmployeesRoutingModule { }

