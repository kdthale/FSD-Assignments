import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';

import { EmployeesComponent } from './employees.component';
import { HeaderService } from '../header/header.service';
import { EmployeesModule } from './employees.module';
import { EmployeesService } from './services/employees.service';
import { EmployeeList } from '../mock-data/employee-mock';

describe('EmployeesComponent', () => {
  let component: EmployeesComponent;
  let employeesService: EmployeesService;
  let fixture: ComponentFixture<EmployeesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([]),
        EmployeesModule
      ],
      providers: [HeaderService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeesComponent);
    component = fixture.componentInstance;
    employeesService = fixture.debugElement.injector.get(EmployeesService);
  });

  afterEach(() => fixture.destroy());

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should diplay rows with correct data', () => {
    spyOn(employeesService, 'getEmployees').and.returnValue(of(EmployeeList));
    fixture.detectChanges();

    const headerElement = fixture.nativeElement.querySelectorAll('tr') as HTMLElement;
    expect(headerElement[1].textContent).toContain(EmployeeList[0].firstName);
    expect(headerElement[1].textContent).toContain(EmployeeList[0].lastName);
    expect(headerElement[1].textContent).toContain(EmployeeList[0].emailId);
  });

  it('should call rowClick method on click of table row', () => {
    spyOn(employeesService, 'getEmployees').and.returnValue(of(EmployeeList));
    spyOn(component, 'rowClick').and.callThrough();
    fixture.detectChanges();

    const headerElement = fixture.nativeElement.querySelectorAll('tr') as HTMLElement;
    headerElement[1].click();
    expect(component.rowClick).toHaveBeenCalled();
  });
});
