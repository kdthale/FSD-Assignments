import { of } from 'rxjs';

import { environment } from '../../../environments/environment';
import { EmployeeList, EmployeeDetailsData } from '../../mock-data/employee-mock';
import { Employee, EmployeeDetails } from '../models/employee.model';
import { EmployeesService } from './employees.service';

describe('employee service', () => {

  let employeesService: EmployeesService;
  let httpClientSpy: { get: jasmine.Spy };

  beforeEach(() => {
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    employeesService = new EmployeesService(<any> httpClientSpy);
  });

  it('should return expected Employees (HttpClient called once)', () => {
    const expectedHeroes: Employee[] = EmployeeList;

    httpClientSpy.get.and.returnValue(of(expectedHeroes));

    employeesService.getEmployees().subscribe(
      employees => expect(employees).toEqual(expectedHeroes, EmployeeList),
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

  it('should return expected Employees (HttpClient called once)', () => {
    environment.production = true;
    const expectedEmployeeDetails: EmployeeDetails = EmployeeDetailsData;

    httpClientSpy.get.and.returnValue(of(expectedEmployeeDetails));

    employeesService.getEmployeeDetails(1).subscribe(
      employees => expect(employees).toEqual(expectedEmployeeDetails, EmployeeDetailsData),
      fail
    );
    expect(httpClientSpy.get.calls.count()).toBe(1, 'one call');
  });

});
