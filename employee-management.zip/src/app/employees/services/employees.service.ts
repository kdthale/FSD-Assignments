import { Injectable} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { Employee, EmployeeDetails } from '../models/employee.model';

export interface EmployeesResponse {
  Employees: Employee[];
}
@Injectable()
export class EmployeesService {

  constructor( private readonly httpClient: HttpClient ) {}

  public getEmployees(): Observable<Employee[]> {
    return this.httpClient.get(environment.employeesUrl)
      .pipe(map((result) => this.parseEmployeesData(result)));
  }

  private parseEmployeesData(data: any): Employee[] {
    return data.map((employee: any) => this.parseEmployees(employee));
  }

  private parseEmployees(employee: any): Employee {
    return {
      id: employee.id,
      firstName: employee.firstName,
      lastName: employee.lastName,
      projectName: employee.projectName,
      emailId: employee.emailId,
      mobileNumber: employee.mobileNumber
    };
  }

  public getEmployeeDetails(employeeId: number): Observable<EmployeeDetails> {
    return this.httpClient.get(`${environment.employeeDetailsUrl}/${employeeId}`)
    .pipe(map((result) => this.parseEmployeeDetailsData(result)));
  }

  private parseEmployeeDetailsData(employeeDetails: any): EmployeeDetails {
    return {
      id: employeeDetails.id,
      firstName: employeeDetails.firstName,
      lastName: employeeDetails.lastName,
      projectName: employeeDetails.projectName,
      emailId: employeeDetails.emailId,
      mobileNumber: employeeDetails.mobileNumber,
      gender: employeeDetails.gender,
      workAddress: employeeDetails.workAddress,
      homeAddress: employeeDetails.homeAddress,
      rating: employeeDetails.rating,
      hobbies: employeeDetails.hobbies
    };
  }
}
