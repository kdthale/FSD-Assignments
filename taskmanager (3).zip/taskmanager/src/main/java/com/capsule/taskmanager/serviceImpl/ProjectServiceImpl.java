package com.capsule.taskmanager.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capsule.taskmanager.exceptionhandler.ResourceNotFoundException;
import com.capsule.taskmanager.model.Project;
import com.capsule.taskmanager.repository.ProjectRepo;
import com.capsule.taskmanager.service.ProjectService;

@Service("projectService")
public class ProjectServiceImpl implements ProjectService{
	
	private ProjectRepo projectRepo;
	
	@Autowired
	public ProjectServiceImpl(ProjectRepo projectRepo) {		
		this.projectRepo = projectRepo;
	}

	@Override
	public void createProject(Project project) {
		projectRepo.save(project);
	}

	@Override
	public List<Project> getProject() {
		return projectRepo.findAll();
	}

	@Override
	public Project findProjectByProjectName(String projectName) {
		Project project = projectRepo.findProjectByProjectName(projectName);
		return project;
	}

	@Override
	public Project findProjectById(Long projectId) {
		Project project = projectRepo.findById(projectId).orElseThrow(() -> new ResourceNotFoundException("Project", "ProjectId", projectId));
		return project;
	}

	@Override
	public void editProject(Project project, Long projectId) {
		
		Project newProject = projectRepo.findById(projectId).orElseThrow(() -> new ResourceNotFoundException("Project", "ProjectId", projectId));
		newProject.setProjectName(project.getProjectName());
		newProject.setPriority(project.getPriority());
		newProject.setProjectEndDate(project.getProjectEndDate());
		newProject.setProjectStartDate(project.getProjectStartDate());
		projectRepo.save(newProject);		
	}

	@Override
	public void suspendProject(Long projectId) {
		
		Project newProject = projectRepo.findById(projectId).orElseThrow(() -> new ResourceNotFoundException("Project", "ProjectId", projectId));
		newProject.setPriority(newProject.getPriority());
		newProject.setProjectEndDate(newProject.getProjectEndDate());
		newProject.setProjectId(newProject.getProjectId());
		newProject.setProjectName(newProject.getProjectName());
		newProject.setProjectStartDate(newProject.getProjectStartDate());
		newProject.setProjectStatus("Finished");
		projectRepo.save(newProject);
	}

}
